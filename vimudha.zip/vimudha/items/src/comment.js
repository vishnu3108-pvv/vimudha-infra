
{/* <footer>
        <div>
            <h3>Location</h3>
            <p>Gurunanak Nagar Road ,behind cafe coffeeday,Plot No-3,Vijayawada-8 </p>
        </div>

        <div>
            <h3>Quick Links</h3>
            <ul>
                <li><a href="http://localhost:3000/Register">Register</a></li>
                
                
            </ul>
        </div>

        <div>
            <h3>Social Media</h3>
            <div className='social'>
    <a href="https://www.instagram.com/vimudharao/"><FaInstagram /></a>
    <a href="https://facebook.com/61553614865820"><FaFacebook /></a>
    <a href="https://www.youtube.com/@vimudhainfraprojects"><FaYoutube /></a>
    

    
   
   
   
</div>
        </div>


    </footer> */}

<footer>







</footer>